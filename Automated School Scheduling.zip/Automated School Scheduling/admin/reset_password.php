<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/forget_password.css">
</head>
<body>
    <div class="background"></div>
    <div class="container">
        <div class="right-side">
            <div class="header">
                <h2>Reset Password</h2>
            </div>
            <form action="../php/reset_password_process.php" method="POST">
                <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']); ?>">
                <div class="input-group">
                    <label for="password">New Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="verify-btn">Reset Password</button>
            </form>
        </div>
    </div>
</body>
</html>