<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Management</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Insert Teachers’ Profile</a>
        <a href="schedule.php">Generate Schedule</a>  
        <a href="teachers.php">Teachers</a>
        <a href="teachers-schedule.php">Teachers’ Schedule</a>
        <a href="rooms.php">Room Management</a>
        <a href="account-settings.php">Account Settings</a>
        <a href="logoff.php">Log off</a>
    </div>
    <div class="container">
        <div class="header">
            <h1>Room Management</h1>
        </div>
        <div class="content">
            <h2>Room Management</h2>
            <div class="actions">
                <button onclick="addRoom()">Add Room</button>
                <button id="editButton" onclick="editRoom()" disabled>Edit Room</button>
                <button id="deleteButton" onclick="deleteRoom()" disabled>Delete Room</button>
            </div>
            <div class="data-grid">
                <table id="roomTable">
                    <thead>
                        <tr>
                            <th>Room Code</th>
                            <th>Room Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr onclick="selectRow(this)">
                            <td>101</td>
                            <td>Lecture Hall</td>
                        </tr>
                        <tr onclick="selectRow(this)">
                            <td>202</td>
                            <td>Laboratory</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="footer">
            <p>&copy; 2024 Teachers' Schedule Management</p>
        </div>
    </div>
    <script>
        let selectedRow = null;

        function addRoom() {
            alert('Add Room functionality to be implemented');
        }

        function editRoom() {
            if (selectedRow) {
                let roomCode = selectedRow.cells[0].innerText;
                let roomType = selectedRow.cells[1].innerText;
                let newRoomCode = prompt("Edit Room Code:", roomCode);
                let newRoomType = prompt("Edit Room Type:", roomType);
                if (newRoomCode !== null) selectedRow.cells[0].innerText = newRoomCode;
                if (newRoomType !== null) selectedRow.cells[1].innerText = newRoomType;
            }
        }

        function deleteRoom() {
            if (selectedRow) {
                if (confirm("Are you sure you want to delete this room?")) {
                    selectedRow.remove();
                    selectedRow = null;
                    document.getElementById('editButton').disabled = true;
                    document.getElementById('deleteButton').disabled = true;
                }
            }
        }

        function selectRow(row) {
            if (selectedRow) {
                selectedRow.classList.remove("selected");
            }
            selectedRow = row;
            selectedRow.classList.add("selected");
            document.getElementById('editButton').disabled = false;
            document.getElementById('deleteButton').disabled = false;
        }
    </script>
</body>
</html>