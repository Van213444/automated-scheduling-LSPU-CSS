<?php
session_start();
require '../php/db_connection.php'; // Include your database connection

// Ensure user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: ../php/login.php');
    exit();
}

$email = $_SESSION['email'];

// Fetch user data from the database
$stmt = $pdo->prepare('SELECT * FROM account WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

// Fetch existing invitation code
$stmt = $pdo->prepare('SELECT code FROM invitation_codes WHERE created_by = ?');
$stmt->execute([$email]);
$existingCode = $stmt->fetch();

// Handle form submission to update user details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $pdo->prepare('UPDATE account SET name = ?, email = ?, password = ? WHERE email = ?');
    $stmt->execute([$name, $email, $password, $email]);

    // Update session email if changed
    if ($email !== $_SESSION['email']) {
        $_SESSION['email'] = $email;
    }

    header('Location: account-settings.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/buttons.css">
    <link rel="stylesheet" href="../css/input-group.css">
</head>
<body>
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Insert Teachers’ Profile</a>
        <a href="schedule.php">Generate Schedule</a>  
        <a href="teachers.php">Teachers</a>
        <a href="teachers-schedule.php">Teachers’ Schedule</a>
        <a href="rooms.php">Room Management</a>
        <a href="account-settings.php">Account Settings</a>
        <a href="logoff.php">Log off</a>
    </div>
    <div class="container">
        <div class="header">
            <h1>Account Settings</h1>
        </div>
        <div class="content">
            <?php if (isset($_SESSION['message'])): ?>
                <p><?= htmlspecialchars($_SESSION['message']) ?></p>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>
            <form action="update_account.php" method="post">
                <div class="input-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" readonly>
                </div>
                <div class="input-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" readonly>
                </div>
                <div class="input-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter new password">
                </div>
                <div class="input-group">
                    <label for="generated-code">Generated Code:</label>
                    <div class="code-container">
                        <input type="text" id="generated-code" name="generated-code" value="<?= htmlspecialchars($existingCode['code'] ?? '') ?>" readonly>
                        <span id="code-message"><?= htmlspecialchars($existingCode ? 'You already have a generated code.' : '') ?></span>
                    </div>
                </div>
                <div class="button-container">
                    <button type="submit" class="btn save-btn">Save Changes</button>
                    <button type="button" class="btn delete-btn" onclick="deleteAccount()">Delete Account</button>
                    <button type="button" class="btn generate-btn" onclick="generateCode()">Generate Code</button>
                </div>
            </form>
        </div>
        <div class="footer">
            <p>&copy; 2024 Teachers' Schedule Management</p>
        </div>
    </div>
    <script>
        function deleteAccount() {
            if (confirm('Are you sure you want to delete your account?')) {
                window.location.href = 'delete_account.php';
            }
        }

        function generateCode() {
            window.location.href = '../php/generate_code.php';
        }
    </script>
</body>
</html>