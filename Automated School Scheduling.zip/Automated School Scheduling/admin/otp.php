<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LSPU OTP Verification</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/otp.css">
</head>
<body>
    <div class="background"></div>
    <div class="container otp-container">
        <div class="right-side">
            <div class="header">
                <h2>Enter OTP</h2>
            </div>
            <form action="../php/verify_otp.php" method="POST">
                <div class="input-group">
                    <label for="otp">Enter OTP</label>
                    <input type="text" id="otp" name="otp" required>
                </div>
                <button type="submit" class="verify-btn">Verify OTP</button>
            </form>
        </div>
    </div>
</body>
</html>