<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teachers</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Insert Teachers’ Profile</a>
        <a href="schedule.php">Generate Schedule</a>  
        <a href="teachers.php">Teachers</a>
        <a href="teachers-schedule.php">Teachers’ Schedule</a>
        <a href="rooms.php">Room Management</a>
        <a href="account-settings.php">Account Settings</a>
        <a href="logoff.php">Log off</a>
      
    </div>
<div class="container">
        <div class="header">
            <h1>Teachers</h1>
        </div>
        <div class="content">
            <h2>Teachers List</h2>
            <table id="teachersTable">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Subject</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Rows will be added here by JavaScript -->
                </tbody>
            </table>
        </div>
        <div class="footer">
            <p>&copy; 2024 Teachers' Schedule Management</p>
        </div>
    </div>
    
    <!-- Include your JavaScript at the end of the body -->
    <script>
        // Example data
        const teachers = [
            { firstName: "John", lastName: "Doe", email: "john@example.com", phone: "1234567890", subject: "Mathematics" },
            { firstName: "Jane", lastName: "Smith", email: "jane@example.com", phone: "0987654321", subject: "Physics" }
        ];

        const teachersTable = document.getElementById('teachersTable').getElementsByTagName('tbody')[0];

        function loadTeachersData() {
            teachers.forEach(teacher => {
                const row = teachersTable.insertRow();
                row.insertCell(0).innerText = teacher.firstName;
                row.insertCell(1).innerText = teacher.lastName;
                row.insertCell(2).innerText = teacher.email;
                row.insertCell(3).innerText = teacher.phone;
                row.insertCell(4).innerText = teacher.subject;
            });
        }

        document.addEventListener('DOMContentLoaded', loadTeachersData);
    </script>
</body>
</html>