<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log off</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="sidebar">
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Insert Teachers’ Profile</a>
        <a href="schedule.php">Generate Schedule</a>  
        <a href="teachers.php">Teachers</a>
        <a href="teachers-schedule.php">Teachers’ Schedule</a>
        <a href="rooms.php">Room Management</a>
        <a href="account-settings.php">Account Settings</a>
        <a href="logoff.php">Log off</a>
    </div>
    <div class="container">
        <div class="header">
            <h1>Log off</h1>
        </div>
        <div class="content">
            <h2>Log off</h2>
            <!-- Add your logoff content here -->
        </div>
        <div class="footer">
            <p>&copy; 2024 Teachers' Schedule Management</p>
        </div>
    </div>
</body>
</html>