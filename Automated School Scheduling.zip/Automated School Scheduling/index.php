<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LSPU Online Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="background"></div>
    <div class="container">
        <div class="left-side">
            <div class="logo">
                <img src="pics/school_logo.png" alt="LSPU Logo">
            </div>
            <div class="welcome-text">
                <h1>SIGN-IN TO YOUR LSPU ACCOUNT</h1>
                <a href="https://www.facebook.com/groups/1004436723245418" class="facebook-btn">f</a>
            </div>
        </div>
        <div class="right-side">
            <div class="header">
                <h2>College • Of • Computer • Studies</h2>
            </div>
            <form action="php/login.php" method="POST">
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="input-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="forgot-password">
                    <!-- Updated link to point to forgot_password.php -->
                    <a href="admin/forget_password.php">Forgot Password?</a>
                </div>
                <button type="submit" class="login-btn">Login</button>
            </form>
            <div class="sign-in">
                <a href="#">Sign IN</a>
            </div>
        </div>
    </div>
</body>
</html>