<?php
// hash_new.php
require 'db_connection.php'; // Ensure the database connection is included

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name']; // This needs to be set and passed correctly
    $password = $_POST['password'];

    // Check if the 'name' and 'password' fields are set
    if (!isset($name) || empty($name)) {
        die("Name is required.");
    }

    // Hash the new password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Prepare SQL statement
    $stmt = $pdo->prepare("UPDATE users SET password = ?, name = ? WHERE name = ?");
    $stmt->execute([$hashed_password, $name, $name]);

    echo "Password has been updated successfully.";
}
?>