<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php';
require 'db_connection.php';

session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format");
    }

    try {
        $stmt = $pdo->prepare('SELECT * FROM account WHERE email = ?');
        $stmt->execute([$email]);

        if ($stmt->rowCount() > 0) {
            $otp = rand(100000, 999999);
            $expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));

            $stmt = $pdo->prepare("UPDATE account SET otp = ?, otp_expires_at = ? WHERE email = ?");
            $stmt->execute([$otp, $expires_at, $email]);

            $mail = new PHPMailer(true);

            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'lspuotpccs@gmail.com'; // Your Gmail address
                $mail->Password = 'pxju puwl bosl ibaq'; // Your Gmail password
                $mail->SMTPSecure = 'tls'; // Use TLS encryption
                $mail->Port = 587; // Port 587 for TLS

                $mail->setFrom('lspuotpccs@gmail.com', 'LSPU');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Code';
                $mail->Body = "Your OTP code is: $otp. It expires in 15 minutes.";

                $mail->send();
                header("Location: ../admin/otp_fp.php?email=" . urlencode($email));
                exit();
            } catch (Exception $e) {
                throw new Exception("Failed to send OTP: " . $mail->ErrorInfo);
            }
        } else {
            throw new Exception("Email not found.");
        }
    } catch (Exception $ex) {
        echo "Error: " . $ex->getMessage();
    }
}
?>