<?php
session_start();
require '../php/db_connection.php'; // Include your database connection

// Ensure user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: ../php/login.php');
    exit();
}

$email = $_SESSION['email'];

// Check if the user already has a code
$stmt = $pdo->prepare('SELECT * FROM invitation_codes WHERE created_by = ?');
$stmt->execute([$email]);
$existingCode = $stmt->fetch();

if ($existingCode) {
    // Code already exists
    header('Location: ../admin/account-settings.php');
    exit();
}

// Generate a new unique code
$code = bin2hex(random_bytes(8)); // Generates a 16-character hex code

// Insert the new code into the database
$stmt = $pdo->prepare('INSERT INTO invitation_codes (code, created_by) VALUES (?, ?)');
$stmt->execute([$code, $email]);

header('Location: ../admin/account-settings.php');
exit();