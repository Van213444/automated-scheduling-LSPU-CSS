<?php
session_start();
require 'db_connection.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $pdo->prepare('SELECT * FROM account WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        // Generate a unique OTP
        $otp = rand(100000, 999999);
        $expiresAt = date('Y-m-d H:i:s', strtotime('+15 minutes'));

        // Store the OTP and its expiration in the database
        $stmt = $pdo->prepare('INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)');
        $stmt->execute([$email, $otp, $expiresAt]);

        // Send the OTP email
        $subject = 'Password Reset OTP';
        $message = "Your OTP for password reset is: $otp. It is valid for 15 minutes.";
        mail($email, $subject, $message, 'From: no-reply@yourdomain.com');

        $_SESSION['message'] = 'OTP sent to your email.';
        header('Location: reset_password_process.php?email=' . urlencode($email));
        exit();
    } else {
        $_SESSION['error'] = 'Email not found.';
        header('Location: ../admin/forgot_password.php');
        exit();
    }
}