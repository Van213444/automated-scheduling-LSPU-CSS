<?php
require 'db_connection.php'; // Include your database connection

// Fetch all users
$stmt = $pdo->query('SELECT * FROM account');
$users = $stmt->fetchAll();

foreach ($users as $user) {
    $hashed_password = password_hash($user['password'], PASSWORD_DEFAULT);

    // Update the user's password with the hashed version
    $stmt = $pdo->prepare('UPDATE account SET password = ? WHERE email = ?');
    $stmt->execute([$hashed_password, $user['email']]);
}

echo "Passwords have been hashed and updated.";
?>