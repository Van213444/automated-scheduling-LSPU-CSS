<?php
session_start();
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $otp = $_POST['otp'];
    $email = $_SESSION['email'];

    // Fetch user OTP from database
    $stmt = $pdo->prepare('SELECT otp, otp_expires_at FROM account WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && $user['otp'] == $otp && strtotime($user['otp_expires_at']) > time()) {
        echo 'OTP verified successfully!';
        // Redirect to the dashboard or home page
        header('Location: ../admin/dashboard.php');
    } else {
        echo 'Invalid or expired OTP.';
    }
}
?>