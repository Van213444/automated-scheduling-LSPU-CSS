<?php
session_start(); // Ensure session is started to access $_SESSION

require 'db_connection.php'; // Ensure you include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hash the new password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    try {
        // Prepare SQL statement
        $stmt = $pdo->prepare('UPDATE account SET password = ?, otp = NULL, otp_expires_at = NULL WHERE email = ?');
        // Execute the statement with bound parameters
        $stmt->execute([$hashed_password, $email]);

        // Redirect with a message box
        echo "<script>
            alert('Password has been reset successfully.');
            window.location.href = '../index.php';
        </script>";
    } catch (PDOException $ex) {
        // Handle exceptions and errors
        echo "<script>
            alert('Error: " . addslashes($ex->getMessage()) . "');
            window.location.href = '../index.php';
        </script>";
    }
}
?>