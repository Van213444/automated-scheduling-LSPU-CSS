<?php
session_start();
require 'db_connection.php'; // Include your database connection

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Make sure PHPMailer is installed via Composer

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Fetch user from database
    $stmt = $pdo->prepare('SELECT * FROM account WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Debug: Output user data
    echo '<pre>';
    print_r($user);
    echo '</pre>';
    
    if ($user) {
        // Debug: Output the hashed password
        echo "Hashed password from DB: " . $user['password'] . "<br>";
        echo "Entered password: " . $password . "<br>";
        echo "password_verify result: " . (password_verify($password, $user['password']) ? 'true' : 'false') . "<br>";

        if (password_verify($password, $user['password'])) {
            // Generate OTP
            $otp = rand(100000, 999999);
            $otp_expires_at = date("Y-m-d H:i:s", strtotime('+10 minutes'));

            // Update OTP in database
            $stmt = $pdo->prepare('UPDATE account SET otp = ?, otp_expires_at = ? WHERE email = ?');
            $stmt->execute([$otp, $otp_expires_at, $email]);

            // Send OTP to user via email
            $mail = new PHPMailer(true);
            try {
                //Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Set the SMTP server to send through
                $mail->SMTPAuth = true;
                $mail->Username = 'lspuotpccs@gmail.com'; // SMTP username
                $mail->Password = 'pxju puwl bosl ibaq'; // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
            
                //Recipients
                $mail->setFrom('lspuotpccs@gmail.com', 'LSPU');
                $mail->addAddress($email);
            
                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Code';
                $mail->Body    = "Your OTP code is $otp. It will expire in 10 minutes.";
            
                $mail->send();
                echo "OTP sent successfully.";
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }

            $_SESSION['email'] = $email;

            header('Location: ../admin/otp.php');
            exit();
        } else {
            echo 'Invalid email or password.';
        }
    } else {
        echo 'Invalid email or password.';
    }
}
?>