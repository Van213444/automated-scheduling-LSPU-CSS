<?php
require 'db_connection.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['use_code'])) {
    $code = $_POST['code'];

    // Check if the code is valid and not used
    $stmt = $pdo->prepare('SELECT * FROM invitation_codes WHERE code = ? AND used = 0');
    $stmt->execute([$code]);
    $invitation = $stmt->fetch();

    if ($invitation) {
        // Mark the code as used
        $stmt = $pdo->prepare('UPDATE invitation_codes SET used = 1 WHERE code = ?');
        $stmt->execute([$code]);

        echo 'Invitation code is valid and used.';
    } else {
        echo 'Invalid or already used code.';
    }
}
?>