<?php
session_start(); // Ensure session is started to access $_SESSION

require 'db_connection.php'; // Ensure you include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_SESSION['email']; // Retrieve email from session
    $otp = $_POST['otp']; // OTP input from form

    // Validate email and OTP
    if (!isset($email) || empty($otp)) {
        die("Email or OTP is missing.");
    }

    try {
        // Prepare SQL statement
        $stmt = $pdo->prepare('SELECT otp, otp_expires_at FROM account WHERE email = ? AND otp = ?');
        $stmt->execute([$email, $otp]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            // Output for debugging
            echo "OTP: " . htmlspecialchars($result['otp']) . "<br>";
            echo "OTP Expiry Time: " . htmlspecialchars($result['otp_expires_at']) . "<br>";
            echo "Current Time: " . date('Y-m-d H:i:s') . "<br>";

            // Check if OTP has expired
            if ($result['otp_expires_at'] > date('Y-m-d H:i:s')) {
                // OTP is valid; redirect to password reset page
                header("Location: ../admin/reset_password.php?email=" . urlencode($email));
                exit(); // Always call exit() after header redirection
            } else {
                echo "Invalid OTP or OTP has expired.";
            }
        } else {
            echo "Invalid OTP or OTP has expired.";
        }
    } catch (Exception $ex) {
        // Handle exceptions and errors
        echo "Error: " . $ex->getMessage();
    }
}
?>